package tema2;

public class T2E8 {
    public static void main(String[] args) {
        char char1 = 's';
        char char2 = 'a';
        char char3 = 'l';
        char char4 = 'u';
        char char5 = 'd';

        String cadena = "" + char1 + char2 + char3 + char4 + char5;

        System.out.println(cadena);
    }
}
